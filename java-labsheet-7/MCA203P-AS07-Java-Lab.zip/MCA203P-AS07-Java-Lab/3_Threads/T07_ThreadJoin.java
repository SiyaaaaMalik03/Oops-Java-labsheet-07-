/**
 * Lab Sheet-07 | Multithreading | Q7: join() method
 * The ProcessThread starts first but waits (join) until the DownloadThread has finished.
 *
 * OOP concepts used: inheritance, composition (ProcessThread holds a reference to DownloadThread).
 */
class DownloadThread extends Thread {

    DownloadThread() {
        super("DownloadThread");
    }

    @Override
    public void run() {
        System.out.println(getName() + ": download started...");
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            return;
        }
        System.out.println(getName() + ": download COMPLETED.");
    }
}

class ProcessThread extends Thread {
    private final Thread dependency;           // the thread we have to wait for

    ProcessThread(Thread dependency) {
        super("ProcessThread");
        this.dependency = dependency;
    }

    @Override
    public void run() {
        System.out.println(getName() + ": waiting for " + dependency.getName() + " using join()...");
        try {
            dependency.join();                 // blocks until DownloadThread terminates
        } catch (InterruptedException e) {
            return;
        }
        System.out.println(getName() + ": download finished, now processing the data.");
    }
}

public class T07_ThreadJoin {
    public static void main(String[] args) throws InterruptedException {
        DownloadThread download = new DownloadThread();
        ProcessThread process = new ProcessThread(download);

        process.start();      // started first, but will wait for the download thread
        download.start();

        process.join();
        System.out.println("Main: all work completed.");
    }
}
