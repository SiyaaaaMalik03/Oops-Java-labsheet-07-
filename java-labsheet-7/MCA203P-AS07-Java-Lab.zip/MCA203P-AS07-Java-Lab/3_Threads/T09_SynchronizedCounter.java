/**
 * Lab Sheet-07 | Multithreading | Q9: Thread synchronization
 * Fix for the previous program using
 *   (a) a synchronized METHOD, and
 *   (b) a synchronized BLOCK.
 * Only one thread at a time can hold the object's lock, so count++ is executed by one thread at a
 * time and no update is lost - the result is always correct.
 *
 * OOP concepts used: encapsulation, thread-safe class, Runnable implementation.
 */
class SafeCounter {
    private int count = 0;

    synchronized void incrementUsingMethod() {       // (a) synchronized method
        count++;
    }

    void incrementUsingBlock() {
        synchronized (this) {                         // (b) synchronized block
            count++;
        }
    }

    synchronized int getCount() {
        return count;
    }
}

class SafeIncrementTask implements Runnable {
    private final SafeCounter counter;
    private final int times;
    private final boolean useBlock;

    SafeIncrementTask(SafeCounter counter, int times, boolean useBlock) {
        this.counter = counter;
        this.times = times;
        this.useBlock = useBlock;
    }

    @Override
    public void run() {
        for (int i = 0; i < times; i++) {
            if (useBlock) {
                counter.incrementUsingBlock();
            } else {
                counter.incrementUsingMethod();
            }
        }
    }
}

public class T09_SynchronizedCounter {

    static int runTest(boolean useBlock, int threads, int increments) throws InterruptedException {
        SafeCounter counter = new SafeCounter();
        Thread[] pool = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            pool[i] = new Thread(new SafeIncrementTask(counter, increments, useBlock));
            pool[i].start();
        }
        for (Thread t : pool) {
            t.join();
        }
        return counter.getCount();
    }

    public static void main(String[] args) throws InterruptedException {
        final int THREADS = 4;
        final int INCREMENTS = 500_000;
        int expected = THREADS * INCREMENTS;

        int viaMethod = runTest(false, THREADS, INCREMENTS);
        System.out.println("Synchronized method -> expected " + expected + ", actual " + viaMethod
                + (viaMethod == expected ? "  (CORRECT)" : "  (WRONG)"));

        int viaBlock = runTest(true, THREADS, INCREMENTS);
        System.out.println("Synchronized block  -> expected " + expected + ", actual " + viaBlock
                + (viaBlock == expected ? "  (CORRECT)" : "  (WRONG)"));
    }
}
