/**
 * Lab Sheet-07 | Multithreading | Q2: Create a thread by implementing the Runnable interface
 * and display numbers from 1 to 10.
 * OOP concepts used: interface implementation, polymorphism (Runnable reference), composition.
 */
class NumberPrinter implements Runnable {
    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(Thread.currentThread().getName() + " -> " + i);
            try {
                Thread.sleep(100);            // small delay so the output can be observed
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted: " + e.getMessage());
                return;
            }
        }
    }
}

public class T02_ImplementRunnable {
    public static void main(String[] args) throws InterruptedException {
        Runnable task = new NumberPrinter();             // the job to be done
        Thread thread = new Thread(task, "NumberThread"); // the worker that runs the job
        thread.start();
        thread.join();
        System.out.println("Main thread: numbers 1 to 10 printed.");
    }
}
