/**
 * Lab Sheet-07 | Multithreading | Q1: Create a thread by extending the Thread class
 * and display a message five times.
 * OOP concepts used: inheritance (extends Thread), method overriding (run), constructor.
 */
class MessageThread extends Thread {
    private final String message;

    MessageThread(String message) {
        this.message = message;
    }

    @Override
    public void run() {                       // code executed by the new thread
        for (int i = 1; i <= 5; i++) {
            System.out.println(i + ". " + message);
        }
    }
}

public class T01_ExtendThreadClass {
    public static void main(String[] args) throws InterruptedException {
        MessageThread thread = new MessageThread("Hello from a thread created by extending Thread class!");
        thread.start();                       // start() creates the new thread and calls run()
        thread.join();                        // wait for the thread to finish
        System.out.println("Main thread: work of MessageThread is complete.");
    }
}
