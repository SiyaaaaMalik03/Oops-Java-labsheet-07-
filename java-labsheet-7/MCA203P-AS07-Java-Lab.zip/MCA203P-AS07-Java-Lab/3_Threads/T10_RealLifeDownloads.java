/**
 * Lab Sheet-07 | Multithreading | Q10: Real-life example - downloading files.
 *
 * Thread roles:
 *   Downloader-1/2/3 : each thread downloads ONE file at the same time (parallel work).
 *   Notifier         : waits (join) for all downloaders, then reports the total downloaded.
 *   main thread      : creates and starts the threads.
 * DownloadStats is shared between the threads, so its method is synchronized.
 *
 * OOP concepts used: abstraction (abstract class), inheritance, polymorphism (role()),
 * encapsulation, interface (Runnable), synchronization of a shared object.
 */
abstract class AppTask implements Runnable {
    protected final String taskName;

    AppTask(String taskName) {
        this.taskName = taskName;
    }

    abstract String role();                      // each task describes its own role

    protected void log(String message) {
        System.out.println("[" + Thread.currentThread().getName() + "] " + message);
    }
}

class DownloadStats {                            // shared resource
    private int totalMb = 0;

    synchronized void add(int mb) {
        totalMb += mb;
    }

    synchronized int getTotalMb() {
        return totalMb;
    }
}

class FileDownloadTask extends AppTask {
    private final int sizeMb;
    private final DownloadStats stats;

    FileDownloadTask(String fileName, int sizeMb, DownloadStats stats) {
        super(fileName);
        this.sizeMb = sizeMb;
        this.stats = stats;
    }

    @Override
    String role() {
        return "downloads the file '" + taskName + "' (" + sizeMb + " MB) in parallel with other downloads";
    }

    @Override
    public void run() {
        log("started downloading " + taskName);
        try {
            for (int percent = 25; percent <= 100; percent += 25) {
                Thread.sleep(sizeMb * 10L);      // simulate network time
                log(taskName + " : " + percent + "% done");
            }
        } catch (InterruptedException e) {
            log("download interrupted");
            return;
        }
        stats.add(sizeMb);
        log("finished " + taskName);
    }
}

class NotifierTask extends AppTask {
    private final Thread[] downloads;
    private final DownloadStats stats;

    NotifierTask(Thread[] downloads, DownloadStats stats) {
        super("Notifier");
        this.downloads = downloads;
        this.stats = stats;
    }

    @Override
    String role() {
        return "waits for all downloads using join() and then shows the summary";
    }

    @Override
    public void run() {
        try {
            for (Thread t : downloads) {
                t.join();
            }
        } catch (InterruptedException e) {
            return;
        }
        log("ALL DOWNLOADS COMPLETE. Total downloaded = " + stats.getTotalMb() + " MB");
    }
}

public class T10_RealLifeDownloads {
    public static void main(String[] args) throws InterruptedException {
        DownloadStats stats = new DownloadStats();

        FileDownloadTask[] tasks = {
            new FileDownloadTask("video.mp4", 40, stats),
            new FileDownloadTask("music.mp3", 10, stats),
            new FileDownloadTask("report.pdf", 5, stats)
        };

        Thread[] downloaders = new Thread[tasks.length];
        System.out.println("Role of each thread:");
        for (int i = 0; i < tasks.length; i++) {
            downloaders[i] = new Thread(tasks[i], "Downloader-" + (i + 1));
            System.out.println("  " + downloaders[i].getName() + " -> " + tasks[i].role());
        }
        NotifierTask notifierTask = new NotifierTask(downloaders, stats);
        Thread notifier = new Thread(notifierTask, "Notifier");
        System.out.println("  " + notifier.getName() + "     -> " + notifierTask.role());
        System.out.println();

        for (Thread t : downloaders) {
            t.start();
        }
        notifier.start();
        notifier.join();
    }
}
