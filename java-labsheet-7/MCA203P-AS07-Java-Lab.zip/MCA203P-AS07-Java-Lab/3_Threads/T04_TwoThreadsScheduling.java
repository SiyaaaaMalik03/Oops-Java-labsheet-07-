/**
 * Lab Sheet-07 | Multithreading | Q4: Two threads running simultaneously, printing their own names.
 *
 * OBSERVATION / EXPLANATION (thread scheduling)
 * The output of the two threads is usually interleaved, and the order may change from run to run.
 * Reason: the JVM hands thread scheduling over to the operating system's scheduler. It decides
 * (using time-slicing / priorities) which thread gets the CPU and for how long, so the order of
 * execution is not guaranteed by the programmer.
 *
 * OOP concepts used: inheritance (extends Thread), constructor, getName().
 */
class NamePrinter extends Thread {

    NamePrinter(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("I am " + getName() + " - iteration " + i);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}

public class T04_TwoThreadsScheduling {
    public static void main(String[] args) throws InterruptedException {
        NamePrinter t1 = new NamePrinter("Thread-A");
        NamePrinter t2 = new NamePrinter("Thread-B");

        t1.start();
        t2.start();

        t1.join();
        t2.join();
        System.out.println("Both threads finished. Run again - the interleaving may differ (scheduler decides).");
    }
}
