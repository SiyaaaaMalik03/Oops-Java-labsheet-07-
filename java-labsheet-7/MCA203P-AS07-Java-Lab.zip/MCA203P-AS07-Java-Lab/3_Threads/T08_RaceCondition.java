/**
 * Lab Sheet-07 | Multithreading | Q8: Shared counter WITHOUT synchronization
 *
 * OBSERVATION / EXPLANATION
 * count++ is not atomic; it is three steps: read count, add 1, write count.
 * When several threads do this at the same time, updates are lost (race condition),
 * so the final value is usually LESS than the expected value, and it changes on every run.
 * (increment() is written as read + write, with an occasional yield, only to make the problem
 * show up reliably even on machines with few CPU cores.)
 *
 * OOP concepts used: encapsulation, Runnable implementation, shared object between threads.
 */
class UnsafeCounter {
    private int count = 0;

    void increment() {
        int temp = count;              // step 1: read
        if ((temp & 0xFF) == 0) {
            Thread.yield();            // let another thread run in the middle (makes the race visible)
        }
        count = temp + 1;              // step 2: write  (same as count++, which is NOT thread-safe)
    }

    int getCount() {
        return count;
    }
}

class IncrementTask implements Runnable {
    private final UnsafeCounter counter;
    private final int times;

    IncrementTask(UnsafeCounter counter, int times) {
        this.counter = counter;
        this.times = times;
    }

    @Override
    public void run() {
        for (int i = 0; i < times; i++) {
            counter.increment();
        }
    }
}

public class T08_RaceCondition {
    public static void main(String[] args) throws InterruptedException {
        final int THREADS = 4;
        final int INCREMENTS = 500_000;

        UnsafeCounter counter = new UnsafeCounter();
        Thread[] threads = new Thread[THREADS];
        for (int i = 0; i < THREADS; i++) {
            threads[i] = new Thread(new IncrementTask(counter, INCREMENTS), "Counter-" + (i + 1));
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }

        int expected = THREADS * INCREMENTS;
        System.out.println("Expected value : " + expected);
        System.out.println("Actual value   : " + counter.getCount());
        if (counter.getCount() != expected) {
            System.out.println("Result is INCORRECT: threads overwrote each other's updates (race condition).");
        } else {
            System.out.println("Got the correct value by luck - run the program again to see the race condition.");
        }
    }
}
