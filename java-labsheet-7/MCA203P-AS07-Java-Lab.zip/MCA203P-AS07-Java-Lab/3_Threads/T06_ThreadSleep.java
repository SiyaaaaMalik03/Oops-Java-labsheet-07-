/**
 * Lab Sheet-07 | Multithreading | Q6: Thread.sleep()
 *
 * OBSERVATION / EXPLANATION
 * Thread.sleep(2000) puts only the CURRENT thread into the TIMED_WAITING state for 2 seconds.
 * The CPU is free during that time, so the other thread continues to execute normally.
 * After 2 seconds the sleeping thread becomes RUNNABLE again and resumes.
 *
 * OOP concepts used: inheritance (extends Thread), constructor, polymorphism through run().
 */
class SleepingThread extends Thread {

    SleepingThread() {
        super("Sleeper");
    }

    @Override
    public void run() {
        try {
            System.out.println(getName() + ": going to sleep for 2 seconds...");
            Thread.sleep(2000);
            System.out.println(getName() + ": woke up after 2 seconds!");
        } catch (InterruptedException e) {
            System.out.println(getName() + ": sleep interrupted");
        }
    }
}

class ActiveThread extends Thread {

    ActiveThread() {
        super("Worker");
    }

    @Override
    public void run() {
        try {
            for (int step = 1; step <= 5; step++) {
                System.out.println(getName() + ": working... step " + step);
                Thread.sleep(400);
            }
        } catch (InterruptedException e) {
            System.out.println(getName() + ": interrupted");
        }
        System.out.println(getName() + ": finished work while Sleeper was sleeping.");
    }
}

public class T06_ThreadSleep {
    public static void main(String[] args) throws InterruptedException {
        SleepingThread sleeper = new SleepingThread();
        ActiveThread worker = new ActiveThread();

        sleeper.start();
        worker.start();

        sleeper.join();
        worker.join();
        System.out.println("Main: both threads are done.");
    }
}
