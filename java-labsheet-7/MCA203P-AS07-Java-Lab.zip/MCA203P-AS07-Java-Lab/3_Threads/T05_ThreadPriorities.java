/**
 * Lab Sheet-07 | Multithreading | Q5: Thread priorities
 * MIN_PRIORITY = 1, NORM_PRIORITY = 5, MAX_PRIORITY = 10
 *
 * OBSERVATION / EXPLANATION
 * A higher priority is only a HINT to the scheduler. On a multi-core CPU all three threads may
 * run in parallel, so the higher-priority thread is not guaranteed to start or finish first.
 * Priorities matter mostly when threads compete for a limited CPU.
 *
 * OOP concepts used: inheritance (extends Thread), constructor, encapsulation.
 */
class PriorityTask extends Thread {

    PriorityTask(String name, int priority) {
        super(name);
        setPriority(priority);
    }

    @Override
    public void run() {
        System.out.println(getName() + " (priority " + getPriority() + ") STARTED");
        double result = 0;
        for (int i = 1; i <= 30_000_000; i++) {      // CPU-bound work
            result += Math.sqrt(i);
        }
        System.out.println(getName() + " (priority " + getPriority() + ") FINISHED  [result=" + (long) result + "]");
    }
}

public class T05_ThreadPriorities {
    public static void main(String[] args) throws InterruptedException {
        PriorityTask low  = new PriorityTask("Low-Thread",    Thread.MIN_PRIORITY);
        PriorityTask norm = new PriorityTask("Normal-Thread", Thread.NORM_PRIORITY);
        PriorityTask high = new PriorityTask("High-Thread",   Thread.MAX_PRIORITY);

        low.start();
        norm.start();
        high.start();

        low.join();
        norm.join();
        high.join();
        System.out.println("All threads completed. Priority only influences scheduling; it does not guarantee order.");
    }
}
