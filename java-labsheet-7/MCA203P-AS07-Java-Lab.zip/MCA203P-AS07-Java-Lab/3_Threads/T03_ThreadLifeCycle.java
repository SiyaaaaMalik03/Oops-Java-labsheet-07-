/**
 * Lab Sheet-07 | Multithreading | Q3: Life cycle of a thread
 *
 * Java thread states (Thread.State):
 *   NEW           - thread object created, start() not yet called
 *   RUNNABLE      - ready to run / running on the CPU        (this covers the "Running" state)
 *   BLOCKED       - waiting to acquire a monitor (synchronized) lock held by another thread
 *   WAITING / TIMED_WAITING - waiting (wait/join/sleep ...)  (sleep(ms) -> TIMED_WAITING)
 *   TERMINATED    - run() has finished
 *
 * The program drives a worker thread through all of these states and prints each one.
 * OOP concepts used: inheritance (extends Thread), encapsulation, object monitor (lock object).
 */
class LifeCycleWorker extends Thread {
    private final Object lock;
    volatile boolean goAhead = false;

    LifeCycleWorker(Object lock) {
        super("Worker");
        this.lock = lock;
    }

    @Override
    public void run() {
        while (!goAhead) {                    // busy loop: thread is RUNNABLE (running)
            Thread.onSpinWait();
        }
        synchronized (lock) {                 // main holds this lock -> worker becomes BLOCKED
            System.out.println("   (Worker acquired the lock)");
        }
        try {
            Thread.sleep(500);                // -> TIMED_WAITING
        } catch (InterruptedException e) {
            System.out.println("Worker interrupted");
        }
        System.out.println("   (Worker finishing run())");   // after this the thread is TERMINATED
    }
}

public class T03_ThreadLifeCycle {

    private static void waitForState(Thread t, Thread.State wanted) throws InterruptedException {
        while (t.getState() != wanted) {
            Thread.sleep(5);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object();
        LifeCycleWorker worker = new LifeCycleWorker(lock);

        System.out.println("1. After creating the object   : " + worker.getState());          // NEW

        synchronized (lock) {                          // main keeps the lock for a while
            worker.start();
            System.out.println("2. After start()               : " + worker.getState());      // RUNNABLE
            worker.goAhead = true;
            waitForState(worker, Thread.State.BLOCKED);
            System.out.println("3. Waiting for the lock        : " + worker.getState());      // BLOCKED
        }                                              // lock released here

        waitForState(worker, Thread.State.TIMED_WAITING);
        System.out.println("4. Inside Thread.sleep(500)    : " + worker.getState());          // TIMED_WAITING

        worker.join();
        System.out.println("5. After run() has completed   : " + worker.getState());          // TERMINATED

        System.out.println();
        System.out.println("Note: Java has no separate 'Running' state - a running thread is reported as RUNNABLE.");
    }
}
