# Lab Sheet-07 - Object Oriented Programming Using Java (MCA III Semester)

All programs of the lab sheet (Exception Handling, Packages, Multithreading) in separate files.
Every program is written with OOP concepts (classes/objects, encapsulation, inheritance,
interfaces, abstraction, polymorphism) and has been compiled and run with JDK 21.

## Folder structure

| Folder | Lab-sheet section | Files |
|---|---|---|
| `1_Exceptions/`  | Questions 1-10 (exception handling) | `Ex01_...java` to `Ex10_...java` + 2 custom exception classes |
| `2_Packages/`    | Intermediate 1-10 (packages) | one sub-folder per question (`P01_...` to `P10_...`) |
| `3_Threads/`     | Advance 1-10 (multithreading) | `T01_...java` to `T10_...java` |

`SAMPLE_OUTPUTS.txt` contains the output of every program.

## How to run

**1_Exceptions** (all files in one default package; compile everything once, then run any program)

    cd 1_Exceptions
    javac *.java
    java Ex01_DivideByZero          (use any other class name: Ex02_..., Ex03_..., ...)

Ex07 and Ex10 need `InvalidPasswordException.java` / `InsufficientFundsException.java`, which are
compiled by `javac *.java`.

**2_Packages** - each question is a separate folder with its own package directories. Open the folder
and follow the exact commands in its `HOW_TO_RUN.txt`. Example:

    cd 2_Packages/P01_SimplePackage
    javac -d out mypack/Hello.java MainApp.java
    java -cp out MainApp

**3_Threads**

    cd 3_Threads
    javac *.java
    java T01_ExtendThreadClass      (use any other class name: T02_..., T03_..., ...)

On Windows the same commands work in Command Prompt / PowerShell (JDK 8 or later is required;
tested with JDK 21). In an IDE (Eclipse / IntelliJ / NetBeans) create a project, copy the
files of one folder in, and run the class that has `main()`.

## Notes

* Programs that read input (Ex01-Ex04, Ex06-Ex08, P08, P09) wait for you to type values.
* Thread outputs (T04, T05, T06, T08, T10) can differ from run to run - this is normal and is
  explained in the comments of those programs.
* `2_Packages/P03...` and `P05...` contain `ERROR_OUTPUT.txt` showing the real compiler errors
  for code that is deliberately not allowed (default class / non-public members).
