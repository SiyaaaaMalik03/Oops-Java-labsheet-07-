package college.students;

/** Lab Sheet-07 | Packages | Q10: Student class of package college.students. */
public class Student {
    private final int rollNo;
    private final String name;
    private final String course;

    public Student(int rollNo, String name, String course) {
        this.rollNo = rollNo;
        this.name = name;
        this.course = course;
    }

    public void display() {
        System.out.println("Roll No: " + rollNo + " | Name: " + name + " | Course: " + course);
    }
}
