package college.students;

/** Main program (separate file) that accesses the Student class. Run as: java college.students.Main */
public class Main {
    public static void main(String[] args) {
        Student s1 = new Student(1, "Priya Sharma", "MCA");
        Student s2 = new Student(2, "Karan Mehta", "MCA");
        s1.display();
        s2.display();
    }
}
