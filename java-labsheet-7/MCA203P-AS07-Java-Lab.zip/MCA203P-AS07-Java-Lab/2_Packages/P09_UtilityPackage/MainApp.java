import java.util.Scanner;
import utils.MathUtils;

/** Reuses package "utils": the static methods are called directly with the class name. */
public class MainApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first number  : ");
        double a = sc.nextDouble();
        System.out.print("Enter second number : ");
        double b = sc.nextDouble();

        System.out.println("Addition       : " + MathUtils.add(a, b));
        System.out.println("Subtraction    : " + MathUtils.subtract(a, b));
        System.out.println("Multiplication : " + MathUtils.multiply(a, b));
        sc.close();
    }
}
