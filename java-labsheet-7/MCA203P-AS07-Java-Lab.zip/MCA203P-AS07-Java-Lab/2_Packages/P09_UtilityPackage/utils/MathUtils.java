package utils;

/** Lab Sheet-07 | Packages | Q9: utility class with static methods (no object needed). */
public class MathUtils {

    private MathUtils() { }          // utility class: prevent object creation

    public static double add(double a, double b) {
        return a + b;
    }

    public static double subtract(double a, double b) {
        return a - b;
    }

    public static double multiply(double a, double b) {
        return a * b;
    }
}
