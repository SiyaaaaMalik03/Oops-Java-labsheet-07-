import java.util.ArrayList;    // system (built-in) package java.util
import java.util.Scanner;

/**
 * Lab Sheet-07 | Packages | Q8: Using ArrayList and Scanner from the built-in package java.util.
 * Classes of java.lang (String, System, Math ...) are imported automatically; everything else
 * from system packages must be imported.
 */
class NameManager {
    private final ArrayList<String> names = new ArrayList<>();

    void add(String name) {
        names.add(name);
    }

    void display() {
        System.out.println("Names in the list (" + names.size() + "):");
        for (int i = 0; i < names.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + names.get(i));
        }
    }

    boolean contains(String name) {
        return names.contains(name);
    }
}

public class UtilDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NameManager manager = new NameManager();

        System.out.print("How many names do you want to enter? ");
        int n = Integer.parseInt(sc.nextLine().trim());
        for (int i = 1; i <= n; i++) {
            System.out.print("Enter name " + i + ": ");
            manager.add(sc.nextLine());
        }
        manager.display();

        System.out.print("Search for a name: ");
        String key = sc.nextLine();
        System.out.println(manager.contains(key) ? key + " is present in the list." : key + " is NOT in the list.");
        sc.close();
    }
}
