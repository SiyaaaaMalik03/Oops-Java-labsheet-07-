package animals;

/** Lab Sheet-07 | Packages | Q6: Dog class of package "animals". */
public class Dog {
    private final String name;

    public Dog(String name) {
        this.name = name;
    }

    public void bark() {
        System.out.println(name + " says: Woof! Woof!");
    }
}
