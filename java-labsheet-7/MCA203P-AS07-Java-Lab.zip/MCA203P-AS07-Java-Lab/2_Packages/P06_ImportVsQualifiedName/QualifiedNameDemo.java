/**
 * (b) fully qualified name: no import statement, the complete name (package.Class) is written
 * every time the class is used.
 *
 * COMPARISON
 *  import statement : code is shorter and cleaner; best when a class is used many times.
 *  qualified name   : no import needed; useful when two packages contain classes with the same
 *                     name (e.g. java.util.Date and java.sql.Date) or for a one-time use.
 *  Both compile to exactly the same bytecode - there is no performance difference.
 */
public class QualifiedNameDemo {
    public static void main(String[] args) {
        animals.Dog dog = new animals.Dog("Tommy");
        dog.bark();
    }
}
