import animals.Dog;           // (a) import statement: afterwards the short name "Dog" can be used

public class ImportDemo {
    public static void main(String[] args) {
        Dog dog = new Dog("Bruno");
        dog.bark();
    }
}
