package demo;

/** Lab Sheet-07 | Packages | Q5: a class with public, protected, default and private members. */
public class AccessDemo {
    public    String publicVar    = "public variable";
    protected String protectedVar = "protected variable";
              String defaultVar   = "default (package-private) variable";
    private   String privateVar   = "private variable";

    public    void publicMethod()    { System.out.println("publicMethod() called"); }
    protected void protectedMethod() { System.out.println("protectedMethod() called"); }
              void defaultMethod()   { System.out.println("defaultMethod() called"); }
    private   void privateMethod()   { System.out.println("privateMethod() called"); }

    /** Public getter: the only way for outside code to reach the private variable. */
    public String getPrivateVar() {
        return privateVar;
    }

    /** Inside the class itself, every member is accessible. */
    public void showAllInsideClass() {
        System.out.println("Inside the class: " + publicVar + ", " + protectedVar + ", " + defaultVar + ", " + privateVar);
        publicMethod();
        protectedMethod();
        defaultMethod();
        privateMethod();
    }
}
