package demo;

/** A class in the SAME package: public, protected and default members are accessible; private is not. */
public class SamePackageTester {
    public static void main(String[] args) {
        AccessDemo obj = new AccessDemo();
        System.out.println("--- Access from the same package ---");
        System.out.println(obj.publicVar);       // OK
        System.out.println(obj.protectedVar);    // OK (same package)
        System.out.println(obj.defaultVar);      // OK (same package)
        // System.out.println(obj.privateVar);   // ERROR: private
        obj.publicMethod();
        obj.protectedMethod();
        obj.defaultMethod();
    }
}
