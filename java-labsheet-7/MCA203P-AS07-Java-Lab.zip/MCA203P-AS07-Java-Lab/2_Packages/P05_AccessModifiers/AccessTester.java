import demo.AccessDemo;

/**
 * Class OUTSIDE package "demo": tests which members of AccessDemo are accessible.
 *
 * RESULT TABLE
 *   Modifier    | same class | same package | subclass (other pkg) | other pkg (non-subclass)
 *   public      |    yes     |     yes      |         yes          |          yes
 *   protected   |    yes     |     yes      |         yes          |          NO
 *   default     |    yes     |     yes      |         NO           |          NO
 *   private     |    yes     |     NO       |         NO           |          NO
 * The lines that do not compile are shown in ERROR_OUTPUT.txt.
 */
public class AccessTester {
    public static void main(String[] args) {
        AccessDemo obj = new AccessDemo();

        System.out.println("--- Access from a different package (not a subclass) ---");
        System.out.println(obj.publicVar);            // OK
        obj.publicMethod();                           // OK
        System.out.println(obj.getPrivateVar());      // OK - private value reached through a public getter

        // System.out.println(obj.protectedVar);      // ERROR: protected access
        // System.out.println(obj.defaultVar);        // ERROR: not public
        // System.out.println(obj.privateVar);        // ERROR: private access
        // obj.protectedMethod();  obj.defaultMethod();  obj.privateMethod();   // ERRORS

        System.out.println();
        new ChildAccess().showInherited();            // protected members work via inheritance

        System.out.println();
        System.out.println("--- Everything is accessible inside the class itself ---");
        obj.showAllInsideClass();
    }
}
