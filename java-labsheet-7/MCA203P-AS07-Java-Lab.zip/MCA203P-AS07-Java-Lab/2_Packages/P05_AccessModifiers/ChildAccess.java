import demo.AccessDemo;

/** Subclass OUTSIDE the package: protected members are accessible through inheritance. */
public class ChildAccess extends AccessDemo {

    public void showInherited() {
        System.out.println("--- Access from a subclass outside the package ---");
        System.out.println(publicVar);           // OK
        System.out.println(protectedVar);        // OK (inherited)
        publicMethod();                          // OK
        protectedMethod();                       // OK (inherited)
        // defaultVar / privateVar are NOT accessible here
    }
}
