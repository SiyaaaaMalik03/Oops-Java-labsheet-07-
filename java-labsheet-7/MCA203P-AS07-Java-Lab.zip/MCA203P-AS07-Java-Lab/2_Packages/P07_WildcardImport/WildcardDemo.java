import mypackage.*;           // wildcard import: gives access to ALL public classes of mypackage

public class WildcardDemo {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        C c = new C();
        a.show();
        b.show();
        c.show();
    }
}
