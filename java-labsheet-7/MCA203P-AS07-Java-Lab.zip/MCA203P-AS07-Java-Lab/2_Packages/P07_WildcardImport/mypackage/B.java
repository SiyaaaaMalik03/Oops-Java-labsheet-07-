package mypackage;

/** Lab Sheet-07 | Packages | Q7: class B of package "mypackage". */
public class B {
    public void show() {
        System.out.println("Method show() of class B in package mypackage");
    }
}
