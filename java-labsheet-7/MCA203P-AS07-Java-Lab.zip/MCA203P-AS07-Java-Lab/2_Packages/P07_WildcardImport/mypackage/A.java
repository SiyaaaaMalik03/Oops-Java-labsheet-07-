package mypackage;

/** Lab Sheet-07 | Packages | Q7: class A of package "mypackage". */
public class A {
    public void show() {
        System.out.println("Method show() of class A in package mypackage");
    }
}
