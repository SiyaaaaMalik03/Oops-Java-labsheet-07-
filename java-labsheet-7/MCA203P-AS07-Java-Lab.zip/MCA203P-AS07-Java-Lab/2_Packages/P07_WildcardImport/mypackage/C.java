package mypackage;

/** Lab Sheet-07 | Packages | Q7: class C of package "mypackage". */
public class C {
    public void show() {
        System.out.println("Method show() of class C in package mypackage");
    }
}
