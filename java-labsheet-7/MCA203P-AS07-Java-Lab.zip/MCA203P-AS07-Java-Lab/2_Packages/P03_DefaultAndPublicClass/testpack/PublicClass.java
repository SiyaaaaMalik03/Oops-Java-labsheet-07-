package testpack;

/** Lab Sheet-07 | Packages | Q3: PUBLIC class - visible everywhere. */
public class PublicClass {

    public void show() {
        System.out.println("PublicClass.show(): I am a public class, accessible from any package.");
    }

    /** Inside the same package the default class IS accessible. */
    public void useDefaultClassInternally() {
        DefaultClass internal = new DefaultClass();
        internal.show();
    }
}
