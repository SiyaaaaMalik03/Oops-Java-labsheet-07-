package testpack;

/** Lab Sheet-07 | Packages | Q3: DEFAULT (non-public) class - visible only inside package testpack. */
class DefaultClass {

    void show() {
        System.out.println("DefaultClass.show(): I am a default class, accessible only within package testpack.");
    }
}
