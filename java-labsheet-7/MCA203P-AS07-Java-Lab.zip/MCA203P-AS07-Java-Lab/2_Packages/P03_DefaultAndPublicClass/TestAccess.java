import testpack.PublicClass;
// import testpack.DefaultClass;   // <-- ERROR: DefaultClass is not public in testpack

/**
 * Accesses both classes of package testpack from another program.
 *
 * OBSERVATION:
 *  - PublicClass can be imported and used from outside the package.
 *  - DefaultClass cannot: the compiler reports "testpack.DefaultClass is not public in testpack;
 *    cannot be accessed from outside package" (see ERROR_OUTPUT.txt).
 *  - Outside code can still reach DefaultClass indirectly through a public method of PublicClass.
 */
public class TestAccess {
    public static void main(String[] args) {
        PublicClass pub = new PublicClass();
        pub.show();                          // OK
        pub.useDefaultClassInternally();     // OK (access to DefaultClass happens inside the package)

        // DefaultClass def = new DefaultClass();   // COMPILE ERROR - uncomment to observe
    }
}
