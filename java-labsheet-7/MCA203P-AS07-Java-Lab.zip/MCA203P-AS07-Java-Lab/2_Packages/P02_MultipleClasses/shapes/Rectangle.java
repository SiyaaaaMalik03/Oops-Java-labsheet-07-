package shapes;

/** Lab Sheet-07 | Packages | Q2: Rectangle class of package "shapes". */
public class Rectangle implements Shape {
    private final double length;
    private final double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double area() {
        return length * width;
    }
}
