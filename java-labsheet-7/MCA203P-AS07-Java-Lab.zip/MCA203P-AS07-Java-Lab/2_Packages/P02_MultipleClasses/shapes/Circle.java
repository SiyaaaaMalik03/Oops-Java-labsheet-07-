package shapes;

/** Lab Sheet-07 | Packages | Q2: Circle class of package "shapes". */
public class Circle implements Shape {
    private final double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
}
