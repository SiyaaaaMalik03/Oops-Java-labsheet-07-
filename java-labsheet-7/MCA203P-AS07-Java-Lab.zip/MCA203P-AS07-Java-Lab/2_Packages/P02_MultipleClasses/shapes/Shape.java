package shapes;

/** Common interface implemented by every shape in the package (abstraction). */
public interface Shape {
    double area();
}
