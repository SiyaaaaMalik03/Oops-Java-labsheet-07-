import shapes.Circle;
import shapes.Rectangle;
import shapes.Shape;

/** Imports package "shapes" and calculates the area of both shapes (polymorphism via Shape). */
public class AreaCalculator {
    public static void main(String[] args) {
        Shape circle = new Circle(7);
        Shape rectangle = new Rectangle(10, 5);

        System.out.printf("Area of Circle (radius 7)           = %.2f%n", circle.area());
        System.out.printf("Area of Rectangle (10 x 5)          = %.2f%n", rectangle.area());
    }
}
