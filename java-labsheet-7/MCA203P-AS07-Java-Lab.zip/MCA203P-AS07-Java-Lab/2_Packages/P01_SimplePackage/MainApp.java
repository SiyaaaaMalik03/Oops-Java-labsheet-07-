import mypack.Hello;          // import the user-defined package class

/** Uses the Hello class from package mypack. */
public class MainApp {
    public static void main(String[] args) {
        Hello hello = new Hello();
        hello.display();
    }
}
