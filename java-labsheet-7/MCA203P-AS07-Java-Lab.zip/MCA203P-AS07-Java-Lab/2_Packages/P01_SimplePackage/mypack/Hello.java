package mypack;

/**
 * Lab Sheet-07 | Packages | Q1: user-defined package "mypack" with class Hello.
 */
public class Hello {

    public void display() {
        System.out.println("Hello! This message is from class Hello in package mypack.");
    }
}
