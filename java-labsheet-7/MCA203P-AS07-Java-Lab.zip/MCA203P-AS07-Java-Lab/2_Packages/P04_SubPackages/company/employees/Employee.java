package company.employees;

/** Lab Sheet-07 | Packages | Q4: Employee class in the sub-package company.employees. */
public class Employee {
    private final int id;
    private final String name;
    private final double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getSalary() { return salary; }

    public void display() {
        System.out.println("Employee ID: " + id + " | Name: " + name + " | Salary: " + salary);
    }
}
