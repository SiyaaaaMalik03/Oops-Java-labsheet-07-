package company.main;

import company.employees.Employee;

/** Program in package company.main that imports and uses Employee from company.employees. */
public class MainApp {
    public static void main(String[] args) {
        Employee e1 = new Employee(101, "Amit Verma", 45000);
        Employee e2 = new Employee(102, "Neha Singh", 52000);
        e1.display();
        e2.display();
    }
}
