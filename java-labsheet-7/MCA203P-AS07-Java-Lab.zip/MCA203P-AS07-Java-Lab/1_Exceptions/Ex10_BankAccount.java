/**
 * Lab Sheet-07 | Exception Handling | Q10: Banking example (user-defined + built-in exceptions)
 *   amount > balance  -> InsufficientFundsException (user-defined)
 *   amount < 0        -> IllegalArgumentException   (built-in)
 * (Needs InsufficientFundsException.java in the same folder.)
 * OOP concepts used: encapsulation, constructor, custom exception (inheritance).
 */
class BankAccount {
    private final String holderName;
    private double balance;

    BankAccount(String holderName, double balance) {
        this.holderName = holderName;
        this.balance = balance;
    }

    void withdraw(double amount) throws InsufficientFundsException {
        if (amount < 0) {
            throw new IllegalArgumentException("Withdrawal amount cannot be negative: " + amount);
        }
        if (amount > balance) {
            double shortfall = amount - balance;
            throw new InsufficientFundsException(
                "Insufficient funds! Balance = " + balance + ", requested = " + amount, shortfall);
        }
        balance -= amount;
        System.out.println("Withdrawn " + amount + ". New balance = " + balance);
    }

    double getBalance() {
        return balance;
    }

    String getHolderName() {
        return holderName;
    }
}

public class Ex10_BankAccount {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Rahul Sharma", 5000);
        System.out.println("Account holder: " + account.getHolderName() + ", opening balance = " + account.getBalance());

        double[] attempts = {2000, 10000, -500, 3000};   // valid, too large, negative, valid
        for (double amount : attempts) {
            System.out.println();
            System.out.println("Trying to withdraw: " + amount);
            try {
                account.withdraw(amount);
            } catch (InsufficientFundsException e) {
                System.out.println("InsufficientFundsException: " + e.getMessage()
                    + " (short by " + e.getShortfall() + ")");
            } catch (IllegalArgumentException e) {
                System.out.println("IllegalArgumentException: " + e.getMessage());
            }
        }
        System.out.println();
        System.out.println("Final balance = " + account.getBalance());
    }
}
