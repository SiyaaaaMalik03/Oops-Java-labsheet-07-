import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q4: Nested try blocks
 *   Inner try : access an array element
 *   Outer try : divide two numbers
 * OOP concepts used: class and object, encapsulation.
 */
class NestedOperations {
    private final int[] numbers = {5, 10, 15};

    int getElement(int index) {
        return numbers[index];
    }

    int divide(int a, int b) {
        return a / b;
    }

    int length() {
        return numbers.length;
    }
}

public class Ex04_NestedTry {
    public static void main(String[] args) {
        NestedOperations ops = new NestedOperations();
        Scanner sc = new Scanner(System.in);

        try {                                           // ---- OUTER try ----
            System.out.println("Outer try block started.");

            try {                                       // ---- INNER try ----
                System.out.print("Enter array index (0 to " + (ops.length() - 1) + "): ");
                int index = sc.nextInt();
                System.out.println("Inner try: element = " + ops.getElement(index));
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Inner catch: invalid array index -> " + e.getMessage());
            }

            System.out.print("Enter two numbers to divide: ");
            int a = sc.nextInt();
            int b = sc.nextInt();
            System.out.println("Outer try: result = " + ops.divide(a, b));
        } catch (ArithmeticException e) {
            System.out.println("Outer catch: division by zero -> " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Outer catch: unexpected input -> " + e);
        } finally {
            System.out.println("Finally: program finished.");
            sc.close();
        }
    }
}
