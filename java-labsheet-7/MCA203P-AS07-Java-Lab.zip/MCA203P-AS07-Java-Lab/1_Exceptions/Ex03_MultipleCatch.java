import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q3: Multiple catch blocks
 * Two numbers are accepted as Strings, converted to int and divided.
 * OOP concepts used: class and object, method abstraction.
 */
class SafeCalculator {
    int divide(String first, String second) {
        int a = Integer.parseInt(first.trim());    // may throw NumberFormatException
        int b = Integer.parseInt(second.trim());   // may throw NumberFormatException
        return a / b;                              // may throw ArithmeticException
    }
}

public class Ex03_MultipleCatch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first number  : ");
        String s1 = sc.nextLine();
        System.out.print("Enter second number : ");
        String s2 = sc.nextLine();

        SafeCalculator calc = new SafeCalculator();
        try {
            System.out.println("Result = " + calc.divide(s1, s2));
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException: input is not a valid integer -> " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException: cannot divide by zero -> " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
