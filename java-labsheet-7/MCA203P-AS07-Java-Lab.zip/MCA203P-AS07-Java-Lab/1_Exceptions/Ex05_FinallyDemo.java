/**
 * Lab Sheet-07 | Exception Handling | Q5: finally block demonstration
 * "Resource closed" is printed from the finally block in BOTH cases:
 * when the operation succeeds and when it throws an exception.
 * OOP concepts used: class and object, encapsulation.
 */
class Resource {
    private final String name;

    Resource(String name) {
        this.name = name;
    }

    void open() {
        System.out.println(name + " opened");
    }

    void performOperation(boolean shouldFail) {
        System.out.println("Performing operation on " + name + "...");
        if (shouldFail) {
            throw new IllegalStateException("Something went wrong during the operation!");
        }
        System.out.println("Operation completed successfully.");
    }

    void close() {
        System.out.println("Resource closed");
    }
}

public class Ex05_FinallyDemo {

    static void runScenario(boolean shouldFail) {
        Resource resource = new Resource("File");
        try {
            resource.open();
            resource.performOperation(shouldFail);
        } catch (IllegalStateException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            resource.close();      // always executed
        }
    }

    public static void main(String[] args) {
        System.out.println("--- Scenario 1: no exception ---");
        runScenario(false);

        System.out.println();
        System.out.println("--- Scenario 2: exception occurs ---");
        runScenario(true);
    }
}
