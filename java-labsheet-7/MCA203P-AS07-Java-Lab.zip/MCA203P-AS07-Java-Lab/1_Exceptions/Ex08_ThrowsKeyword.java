import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q8: Using the throws keyword
 * readNumber() declares "throws NumberFormatException"; the calling method (main) handles it.
 * OOP concepts used: class and object, method abstraction.
 */
class NumberReader {
    /** Reads a line from the user and converts it to int. Exception is passed to the caller. */
    int readNumber(Scanner sc) throws NumberFormatException {
        System.out.print("Enter a number: ");
        String text = sc.nextLine();
        return Integer.parseInt(text.trim());
    }
}

public class Ex08_ThrowsKeyword {
    public static void main(String[] args) {
        NumberReader reader = new NumberReader();
        Scanner sc = new Scanner(System.in);
        try {
            int number = reader.readNumber(sc);
            System.out.println("You entered: " + number + " (square = " + (number * number) + ")");
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException handled in the calling method: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
