import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q7: Creating a User-Defined Exception
 * Throws InvalidPasswordException when the password has less than 6 characters.
 * (Needs InvalidPasswordException.java in the same folder.)
 * OOP concepts used: custom exception class (inheritance), class and object.
 */
class PasswordValidator {
    private static final int MIN_LENGTH = 6;

    void validate(String password) throws InvalidPasswordException {
        if (password.length() < MIN_LENGTH) {
            throw new InvalidPasswordException(
                "Password must have at least " + MIN_LENGTH + " characters (entered: " + password.length() + ").");
        }
        System.out.println("Password accepted.");
    }
}

public class Ex07_CustomException {
    public static void main(String[] args) {
        PasswordValidator validator = new PasswordValidator();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a password: ");
        String password = sc.nextLine();
        try {
            validator.validate(password);
        } catch (InvalidPasswordException e) {
            System.out.println("InvalidPasswordException: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
