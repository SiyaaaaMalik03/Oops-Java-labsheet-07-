/**
 * Lab Sheet-07 | Exception Handling | Q9: finally vs return
 *
 * OBSERVATION / EXPLANATION
 * When a try block executes "return", the following happens in this order:
 *   1. The return expression is evaluated and its value is saved.
 *   2. The finally block is executed (so the finally message is printed FIRST).
 *   3. The method then actually returns the saved value to the caller.
 * Therefore finally runs before the method returns, but the return value is already fixed:
 * changing the variable inside finally does not change a returned primitive value.
 * (A "return" written inside finally would override the try's return - bad practice.)
 *
 * OOP concepts used: class and object, instance methods.
 */
class ReturnDemo {

    int basicReturn() {
        try {
            System.out.println("  [try]     evaluating and returning 10");
            return 10;
        } finally {
            System.out.println("  [finally] runs BEFORE the method actually returns");
        }
    }

    int modifyInFinally() {
        int x = 10;
        try {
            System.out.println("  [try]     returning x = " + x);
            return x;                       // value 10 is saved here
        } finally {
            x = 99;                         // does NOT affect the saved return value
            System.out.println("  [finally] x changed to " + x);
        }
    }

    @SuppressWarnings("finally")
    int returnInFinally() {
        try {
            return 10;
        } finally {
            return 20;                      // overrides the try's return (not recommended)
        }
    }
}

public class Ex09_FinallyVsReturn {
    public static void main(String[] args) {
        ReturnDemo demo = new ReturnDemo();

        System.out.println("1) Basic return inside try:");
        int r1 = demo.basicReturn();
        System.out.println("  Method returned: " + r1);

        System.out.println();
        System.out.println("2) Variable modified inside finally:");
        int r2 = demo.modifyInFinally();
        System.out.println("  Method returned: " + r2 + "  (still 10, not 99)");

        System.out.println();
        System.out.println("3) return statement inside finally:");
        int r3 = demo.returnInFinally();
        System.out.println("  Method returned: " + r3 + "  (finally's return overrides try's return)");

        System.out.println();
        System.out.println("Conclusion: the finally block is executed first (before control returns to the caller).");
    }
}
