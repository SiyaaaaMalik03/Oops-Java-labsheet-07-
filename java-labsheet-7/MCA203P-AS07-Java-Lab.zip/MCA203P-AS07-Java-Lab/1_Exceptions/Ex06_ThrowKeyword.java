import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q6: Using the throw keyword
 * checkAge(int age) throws an exception if age < 18; main() handles it.
 * OOP concepts used: class and object, method abstraction.
 */
class AgeValidator {
    void checkAge(int age) {
        if (age < 18) {
            throw new IllegalArgumentException("Age " + age + " is less than 18. Not eligible.");
        }
        System.out.println("Age " + age + " is valid. Eligible.");
    }
}

public class Ex06_ThrowKeyword {
    public static void main(String[] args) {
        AgeValidator validator = new AgeValidator();
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter your age: ");
            int age = sc.nextInt();
            validator.checkAge(age);
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught in main(): " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: Age must be a whole number.");
        } finally {
            sc.close();
        }
    }
}
