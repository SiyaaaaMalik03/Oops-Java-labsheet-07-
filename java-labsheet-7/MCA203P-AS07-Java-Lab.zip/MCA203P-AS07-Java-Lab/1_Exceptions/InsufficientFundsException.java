/**
 * User-defined (custom) checked exception used in Ex10.
 * OOP concepts used: inheritance (extends Exception), encapsulation (private field + getter).
 */
public class InsufficientFundsException extends Exception {
    private static final long serialVersionUID = 1L;

    private final double shortfall;

    public InsufficientFundsException(String message, double shortfall) {
        super(message);
        this.shortfall = shortfall;
    }

    public double getShortfall() {
        return shortfall;
    }
}
