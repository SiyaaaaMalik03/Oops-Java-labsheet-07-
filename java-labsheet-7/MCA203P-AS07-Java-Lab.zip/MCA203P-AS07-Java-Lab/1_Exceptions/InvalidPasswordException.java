/**
 * User-defined (custom) checked exception used in Ex07.
 * OOP concepts used: inheritance (extends Exception), constructor chaining with super().
 */
public class InvalidPasswordException extends Exception {
    private static final long serialVersionUID = 1L;


    public InvalidPasswordException(String message) {
        super(message);
    }
}
