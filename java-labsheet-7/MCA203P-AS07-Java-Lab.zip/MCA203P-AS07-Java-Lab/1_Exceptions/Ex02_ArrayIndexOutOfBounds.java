import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q2: Array Index Out of Bounds
 * OOP concepts used: class and object, encapsulation (array hidden inside the class).
 */
class NumberStore {
    private final int[] data = {10, 20, 30, 40, 50};   // array of 5 elements

    int size() {
        return data.length;
    }

    int getValueAt(int index) {
        return data[index];   // throws ArrayIndexOutOfBoundsException for an invalid index
    }

    void display() {
        System.out.print("Array elements: ");
        for (int value : data) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}

public class Ex02_ArrayIndexOutOfBounds {
    public static void main(String[] args) {
        NumberStore store = new NumberStore();
        store.display();

        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter an index (0 to " + (store.size() - 1) + "): ");
            int index = sc.nextInt();
            System.out.println("Value at index " + index + " = " + store.getValueAt(index));
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Invalid index! " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: Index must be an integer.");
        } finally {
            sc.close();
        }
    }
}
