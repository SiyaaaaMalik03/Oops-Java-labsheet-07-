import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Lab Sheet-07 | Exception Handling | Q1: Divide by Zero (ArithmeticException)
 * OOP concepts used: class and object, encapsulation (private fields), constructor.
 */
class Divider {
    private final int numerator;
    private final int denominator;

    Divider(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    /** Integer division throws ArithmeticException automatically when denominator is 0. */
    int divide() {
        return numerator / denominator;
    }
}

public class Ex01_DivideByZero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter numerator   : ");
            int a = sc.nextInt();
            System.out.print("Enter denominator : ");
            int b = sc.nextInt();

            Divider divider = new Divider(a, b);
            System.out.println("Result = " + divider.divide());
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed. (" + e.getMessage() + ")");
        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid integers only.");
        } finally {
            // The finally block always runs, whether or not an exception occurred.
            System.out.println("finally block: executed (closing Scanner).");
            sc.close();
        }
    }
}
